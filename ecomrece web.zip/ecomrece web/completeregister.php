<?php
    session_start();
    require 'dbconflict/php.php';
    $strName = $_POST['strName'];
    $strEmail = $_POST['strEmail'];
    $strPhone = $_POST['strPhone'];
    $strAddress = $_POST['strAddress'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    if($password!==$cpassword)
    {
        header("Location: register.php?nError=1");
        exit;
    }
    $strQuery = "insert into tblcustomer (cust_Name, cust_Email, cust_Phone, cust_Address, cust_Username, cust_Password) values ('$strName', '$strEmail', '$strPhone', '$strAddress', '$username', '$password')";
    mysqli_query($con, $strQuery);
    header("Location: index.php?bRegister=1");
?>