<?php
    session_start();
    $nProdID = $_GET['nProdID'];
    
    
    setcookie('nCartItem', $nProdID, time() + 86400, "/"); // 86400 = 1 
    
    header("Location: index.php");
?>