-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2018 at 03:25 PM
-- Server version: 5.7.20
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoppingcart`
--
CREATE DATABASE IF NOT EXISTS `shoppingcart` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `shoppingcart`;

-- --------------------------------------------------------

--
-- Table structure for table `tbladminusers`
--

DROP TABLE IF EXISTS `tbladminusers`;
CREATE TABLE `tbladminusers` (
  `adm_ID` int(5) NOT NULL,
  `adm_Username` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `adm_Password` varchar(45) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbladminusers`
--

INSERT INTO `tbladminusers` (`adm_ID`, `adm_Username`, `adm_Password`) VALUES(1, 'admin', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

DROP TABLE IF EXISTS `tblcategory`;
CREATE TABLE `tblcategory` (
  `cat_ID` int(5) UNSIGNED NOT NULL,
  `cat_Title` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`cat_ID`, `cat_Title`) VALUES(6, 'Computer Acsesories');
INSERT INTO `tblcategory` (`cat_ID`, `cat_Title`) VALUES(2, 'Jewellery');
INSERT INTO `tblcategory` (`cat_ID`, `cat_Title`) VALUES(5, 'Mobile Phones');
INSERT INTO `tblcategory` (`cat_ID`, `cat_Title`) VALUES(3, 'Shoes');
INSERT INTO `tblcategory` (`cat_ID`, `cat_Title`) VALUES(4, 'Watches');

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

DROP TABLE IF EXISTS `tblcustomer`;
CREATE TABLE `tblcustomer` (
  `cust_ID` int(5) UNSIGNED NOT NULL,
  `cust_Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cust_Email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cust_Phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `cust_Address` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `cust_Username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cust_Password` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tblcustomer`
--

INSERT INTO `tblcustomer` (`cust_ID`, `cust_Name`, `cust_Email`, `cust_Phone`, `cust_Address`, `cust_Username`, `cust_Password`) VALUES(1, 'Customer 1', 'customer1@order.com', '+923334445678', 'Pakistan', 'customer1', 'password');
INSERT INTO `tblcustomer` (`cust_ID`, `cust_Name`, `cust_Email`, `cust_Phone`, `cust_Address`, `cust_Username`, `cust_Password`) VALUES(2, 'test', 'test@test.com', '1234567', 'Pakistan', 'test', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

DROP TABLE IF EXISTS `tblorder`;
CREATE TABLE `tblorder` (
  `order_ID` int(5) UNSIGNED NOT NULL,
  `prod_ID` int(5) NOT NULL,
  `order_Total` int(5) NOT NULL,
  `order_Status` enum('shipped','pending') COLLATE utf8_unicode_ci NOT NULL,
  `order_Date` datetime NOT NULL,
  `cust_ID` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`order_ID`, `prod_ID`, `order_Total`, `order_Status`, `order_Date`, `cust_ID`) VALUES(1, 1, 0, 'shipped', '2018-10-11 18:45:36', 1);
INSERT INTO `tblorder` (`order_ID`, `prod_ID`, `order_Total`, `order_Status`, `order_Date`, `cust_ID`) VALUES(2, 11, 1500, 'shipped', '2018-10-12 14:38:37', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

DROP TABLE IF EXISTS `tblproducts`;
CREATE TABLE `tblproducts` (
  `prod_ID` int(5) UNSIGNED NOT NULL,
  `prod_Title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `prod_Description` text COLLATE utf8_unicode_ci NOT NULL,
  `prod_Price` int(5) NOT NULL,
  `prod_Image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cat_ID` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tblproducts`
--

INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(1, 'Gold Set', 'This is Gold set', 10000, 'Gold Set7.jpg', 2);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(3, 'Diamond Ring', 'This is diamond ring<span style=\"white-space:pre\">	</span>', 1000, 'Diamond Ring8.jpg', 2);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(4, 'Ear Ring', 'This is earring', 5000, 'Ear Ring9.jpg', 2);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(5, 'Samsung Glaxy S6', 'This is Samsung Galaxy S6', 35000, 'Samsung Glaxy S64.jpg', 5);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(6, 'Huawei 7x', 'This is Huawei 7x', 30000, 'Huawei 7x5.jpg', 5);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(7, 'iPhone 6x Plus', 'This is iPhone 6x', 50000, 'iPhone 6x Plus6.jpg', 5);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(8, 'Casual Shoes', 'This is casual shoes', 4000, 'Casual Shoes1.jpg', 3);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(9, 'Sneakers', 'This is sneakers<span style=\"white-space:pre\">	</span>', 3000, 'Sneakers2.jpg', 3);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(10, 'Jogger Shoes', 'This is joggers shoes', 2500, 'Jogger Shoes3.jpg', 3);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(11, 'Bluetooth Mouse', 'This is bluetooth mouse<span style=\"white-space:pre\">	</span>', 1500, 'Bluetooth Mouse10.jpg', 6);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(12, 'Pen Drive', 'This is pen drive', 1000, 'Pen Drive11.jpg', 6);
INSERT INTO `tblproducts` (`prod_ID`, `prod_Title`, `prod_Description`, `prod_Price`, `prod_Image`, `cat_ID`) VALUES(13, 'Arcade Stick', 'This is arcade stick<span style=\"white-space:pre\">	</span>', 3000, 'Arcade Stick12.jpg', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladminusers`
--
ALTER TABLE `tbladminusers`
  ADD PRIMARY KEY (`adm_ID`),
  ADD UNIQUE KEY `adm_Username_UNIQUE` (`adm_Username`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`cat_ID`),
  ADD UNIQUE KEY `cat_Title` (`cat_Title`);

--
-- Indexes for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  ADD PRIMARY KEY (`cust_ID`);

--
-- Indexes for table `tblorder`
--
ALTER TABLE `tblorder`
  ADD PRIMARY KEY (`order_ID`);

--
-- Indexes for table `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`prod_ID`),
  ADD UNIQUE KEY `prod_Title` (`prod_Title`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladminusers`
--
ALTER TABLE `tbladminusers`
  MODIFY `adm_ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `cat_ID` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblcustomer`
--
ALTER TABLE `tblcustomer`
  MODIFY `cust_ID` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblorder`
--
ALTER TABLE `tblorder`
  MODIFY `order_ID` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `prod_ID` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
