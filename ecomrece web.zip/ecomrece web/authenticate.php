<?php
    session_start();
    require 'dbconflict/php.php';
    
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $strQuery = "select * from tblcustomer where cust_Username='$username' and cust_Password='$password'";
    $nResult = mysqli_query($con, $strQuery);
    $nCount = mysqli_num_rows($nResult);
    if($nCount==1)
    {
        $_SESSION['bCustLogin'] = true;
        $_SESSION['username'] = $username;
        $row = mysqli_fetch_assoc($nResult);
        $_SESSION['userid'] = $row['cust_ID'];
        if(isset($_POST['strRef']) && trim($_POST['strRef'])=='cart')
        {
            header("Location: cart.php");
        }
        else
        {
            header("Location: index.php");
        }
    }
    else {
        if(isset($_POST['strRef']) && trim($_POST['strRef'])=='cart')
        {
            $strRef = '&strRef=cart';
        }
        header("Location: newlogin.php?nError=1".$strRef);
    }
?>