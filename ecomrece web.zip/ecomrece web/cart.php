<?php
    require 'dbconflict/php.php';
    session_start();
?>
<html>
    <head>
        <link href="css/style.css" rel="stylesheet" type="text/css">
        <link href="css/font-awesome.css" rel="stylesheet" type="text/css">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="js/cycle.js"></script>
        <script>
            $('#slider').cycle('all');
        </script>
    </head>
    <body>
        <div id="header">
            <div id="logo">
                <img src="logo/logo2.png">
            </div>
            <div id="list">
                <ul>
                    <li><a href="#"><i class="fa fa-info-circle" aria-hidden="true"></i> Customer Care</a></li>
                    <?php
                        if(isset($_SESSION['bCustLogin']) && $_SESSION['bCustLogin'])
                        {
                            ?>
                            <li id="link_active"><a href="#"><i class="fa fa-user-plus" aria-hidden="true"></i> <H5>Welcome <?php echo $_SESSION['username']?></H5></a></li>
                            <li id="link_active"><a href="logout.php"><input name="logout" type="button" id="logout_btn"> Logout</a></li>
                            <?php
                        }
                        else
                        {
                            ?>
                            <li id="link_active"><a href="register.php"><input name="login" type="button" id="logout_btn"> Register</a></li>
                            <li id="link_active"><a href="newlogin.php"><input name="login" type="button" id="logout_btn"> Login</a></li>
                            <?php
                        }
                    ?>
                    
                </ul>
            </div>
            <div id="search">
                <form method="post">
                    <input type="text" placeholder="Search here">
                    <button id="search_btn"><i class="fa fa-search" aria-hidden="true"></i> Search</button>
                    <?php
                        $nCartItems = 0;
                        if(isset($_COOKIE['nCartItem']) && $_COOKIE['nCartItem']>0)
                        {
                            $nCartItems = 1;
                        }
                    ?>
                    <button id="cart_btn" style="cursor: pointer;" onclick="window.location='cart.php'; return false;"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i> Cart<?php if($nCartItems>0) {echo "($nCartItems)";} ?></button>
                </form>
            </div>
        </div>
        <div id="navbar">
            <ul>
                <li><a href="#"><i class="fa fa-th-large" aria-hidden="true"></i> CATEGORIES</a>
                    <ul>
                        <?php
                            $strQuery = "Select * from tblcategory";
                            $result = mysqli_query($con, $strQuery);
                            while($row= mysqli_fetch_assoc($result))
                            {
                                ?>
                                <li><a href="category.php?nID=<?php echo $row['cat_ID'];?>"><?php echo $row['cat_Title'];?></a></li>
                                <?php
                            }
                        ?>
                    </ul>
                </li>
                <li><a href="#"><i class="fa fa-gift" aria-hidden="true"></i> GIFTS FOR HIM</a>
                    <ul>
                        <li><a href="#">Electronic</a></li>
                        <li><a href="#">Shoes</a></li>
                        <li><a href="#">Books</a></li>
                        <li><a href="#">Mobile Phones</a></li>
                    </ul>
                </li>
                <li><a href="#"><i class="fa fa-gift" aria-hidden="true"></i> GIFTS FOR HER</a>
                    <ul>
                        <li><a href="#">Electronic</a></li>
                        <li><a href="#">Shoes</a></li>
                        <li><a href="#">Books</a></li>
                        <li><a href="#">Mobile Phones</a></li>
                    </ul>
                </li>
                <li><a href="#"><i class="fa fa-gift" aria-hidden="true"></i> GIFTS FOR KIDS</a>
                    <ul>
                        <li><a href="#">Electronic</a></li>
                        <li><a href="#">Shoes</a></li>
                        <li><a href="#">Books</a></li>
                        <li><a href="#">Mobile Phones</a></li>
                    </ul>
                </li>
                <li><a href="#"><i class="fa fa-birthday-cake" aria-hidden="true"></i> BIRTHDAY</a>
                    <ul>
                        <li><a href="#">Electronic</a></li>
                        <li><a href="#">Shoes</a></li>
                        <li><a href="#">Books</a></li>
                        <li><a href="#">Mobile Phones</a></li>
                    </ul>
                </li>
                <li><a href="#"><i class="fa fa-bandcamp" aria-hidden="true"></i> BRANDS</a>
                    <ul>
                        <li><a href="#">Electronic</a></li>
                        <li><a href="#">Shoes</a></li>
                        <li><a href="#">Books</a></li>
                        <li><a href="#">Mobile Phones</a></li>
                    </ul>
                </li>
                <li><a href="#"><i class="fa fa-heart" aria-hidden="true"></i> FOLLOWERS</a>
                    <ul>
                        <li><a href="#">Electronic</a></li>
                        <li><a href="#">Shoes</a></li>
                        <li><a href="#">Books</a></li>
                        <li><a href="#">Mobile Phones</a></li>
                    </ul>
                </li>
            </ul>
        </div><br clear="all" />
        <div id="bodyleft">
            <h3>Your Cart</h3>
            <center>
                <table style="width: 600px;">
                    <tr>
                        <td style="width: 300px;"><b>Product</b></td>
                        <td style="width: 100px;"><b>Quantity</b></td>
                        <td  style="width: 200px;"><b>Price</b></td>
                    </tr>
                    <?php
                        $nProdID = $_COOKIE['nCartItem'];
                        $strQuery = "Select * from tblproducts where prod_ID=".$nProdID;
                        $nResult = mysqli_query($con, $strQuery);
                        $row = mysqli_fetch_assoc($nResult);
                    ?>
                    <tr>
                        <td><?php echo $row['prod_Title'];?></td>
                        <td>1</td>
                        <td><?php echo $row['prod_Price'];?> Rupees</td>
                    </tr>
                    <tr>
                        <td>Total</td>
                        <td>1</td>
                        <td><?php echo $row['prod_Price'];?> Rupees</td>
                    </tr>
                </table>
                <?php
                    if(isset($_SESSION['bCustLogin']) && $_SESSION['bCustLogin'])
                    {
                        ?>
                        <button id="cart_btn" style="cursor: pointer; width: auto" onclick="window.location = 'checkout.php'">Proceed to Checkout</button>
                        <?php
                    }
                    else
                    {
                        ?>
                        <button id="cart_btn" style="cursor: pointer; width: auto" onclick="window.location = 'newlogin.php?strRef=cart'">Login First to Proceed</button>
                        <?php
                    }
                ?>
                
            </center>
        </div>
        <div id="bodyright">
            <h3>Great Deals</h3>
            <ul>
                <li>
                    <a href="#"><img src="ads/adv1.jpg" /></a>
                </li>
                <li>
                    <a href="#"><img src="ads/adv2.jpg" /></a>
                </li>
                <li>
                    <a href="#"><img src="ads/adv3.jpg" /></a>
                </li>
                <li>
                    <a href="#"><img src="ads/adv4.jpg" /></a>
                </li>
            </ul>
        </div>
        <br clear="all" />
        <div id="footer">
           <h4>Copyright 2019 Ecom Developed By Arbab</h4>
        </div>
    </body>
</html>