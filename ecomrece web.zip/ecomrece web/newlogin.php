<html>
    <head>
        <title>:: Login ::</title>
        <link rel="stylesheet" href="csss/login.css" type="text/css">
    </head>
    <body>
        <div class="loginbox">
            <img src="logo.png" class="logo">
            <h1 style="color: black">Login Here</h1>
            <form  class="myform" action="authenticate.php" method="post">
                <p style="color:black">Username</p>
                <input name="username"type="text" name="" placeholder="Enter Username">
                <?php
                    if(isset($_GET['strRef']) && trim($_GET['strRef'])=='cart')
                    {
                        ?>
                        <input type="hidden" id="strRef" name="strRef" value="cart" />
                        <?php
                    }
                ?>
                <p>Password</p>
                <input name="password" type="password" name="" placeholder="Enter Password"><br><br>
                <input name="login" type="submit" name="" value="login"><br>
                <a href="register.php">Don't have an account?</a>
            </form>
            <?php
                if(isset($_GET['nError']) && $_GET['nError']==1)
                {
                    ?>
                    <script>
                        alert('Invali username or password');
                    </script>
                    <?php
                }
            ?>
        </div>
    </body>
</html>