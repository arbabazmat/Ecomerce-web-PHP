<?php
  require 'dbconflict/php.php';
?>
<!DOCTYPE HTML>
<HTML>

<HEAD>
<TITLE>Registration </TITLE>
<link rel="stylesheet" type="text/css" href="csss/stylee.css">
</head>

<BODY  >

	<script type="text/javascript">
		function validation(){
			var ph=document.getElementById('num').value;
			var em=document.getElementById('ema').value;
			var ps=document.getElementById('pass').value;
			var cps=document.getElementById('cpass').value; 
			var nm=document.getElementById('nam').value;
			var addr=document.getElementById('add').value;

if(nm == "")
{
	document.getElementById('us').innerHTML="please enter username";
	return false;
}
if(!isNaN(nm))
	{
	document.getElementById('us').innerHTML="please enter character";
	return false;
}

if(em == "")
{
	document.getElementById('e').innerHTML="please enter email";
	return false;
}

if(ph == "")
{
	document.getElementById('p').innerHTML="please enter phone";
	return false;
}

if(isNaN(ph))
	{
	document.getElementById('p').innerHTML="please enter character";
	return false;
}
if(nm == "")
{
	document.getElementById('ad').innerHTML="address required";
	return false;
}

if(ps == "")
{
	document.getElementById('pa').innerHTML="please enter password";
	return false;
}

if(lenght(ps)<6)
{
	document.getElementById('pa').innerHTML="password lenght should be greater than 6";
	return false;
}
if(cps == "")
{
	document.getElementById('cpa').innerHTML="please enter confirm password";
	return false;
}

if(ps!=cps)
{
	document.getElementById('cpa').innerHTML="password not matching";
	return false;
}







	}

	</script>

<DIV class="loginbox">
 
  <img src="logo.png" class="logo">
            <h1 style="color: black; margin-top: -40px;" >Sign Up  Form</h1>
 

<form  class="myform" action="completeregister.php" method="post" onsubmit="return validation() ">
<label> 
   <div>
 <label><b>Username:</label><br>
<input name="username" type="text" id="nam" class="inputvalues" placeholder="type your username"/><br>
<span id="us" style="color: red"></span>
</div>

 <div>
<label><b>E-Mail:</label><br>
<input name="strEmail" type="text" id="ema" class="inputvalues" placeholder="type your e-mail"/><br>
<span id="e" style="color: red"></span>
</div>

 <div> 
<label><b>Phone:</label><br>
<input name="strPhone" type="text" id="num" class="inputvalues" placeholder="type your phone"/><br>
<span id="p" style="color: red"></span>
</div>

<label><b>Address:</label><br>
<input name="strAddress" type="text" id="add" class="inputvalues" placeholder="type your address"/><br>
 <span id="ad" style="color: red"></span>
  <div> 
<label><b>Password:</label><br>
<input name="password" type="Password" id="pass" class="inputvalues" placeholder="type your password"/><br>
<span id="pa" style="color: red"></span>
</div>

 <div>
 <label><b>Confrim Password:</label><br>
<input name="cpassword" type="Password" id="cpass" class="inputvalues" placeholder="Confirm your password"/><br>
<span id="cpa" style="color: red"></span>
</div>

<input name="submit_btn" type="submit" id="signUp_btn" value="Sign_up"       /> <br>
<a href="newlogin.php">Back to login page</a>

</form>
<?php
include_once('dbconflict/php.php');
if(isset($_POST['submit_btn'])) 
{
 
//isset inbuild function $post globl var which is predcleard or inbuoild whenevr we post some data we can accss that using this wid name tht posted bassicly itx array it will chk butn is clicked or not -->

//echo'<script type="text/javascript">alert ("submit button is click")';</script>
$username = $_POST['username'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];

if($password == $cpassword)
{
$query="select * from user where username='$username'";
$query_run = mysqli_query($con,$query);

if(mysqli_num_rows($query_run)>0)
{
echo '<script type="text/javascript"> alert("User already exist ..try another user name")</script>';
}
else
{
 $query="insert into user values ('$username','$password')";
$query_run= mysqli_query($con,$query);

if($query_run)
{echo'<script type="text/javascript">
alert ("User Registered.. Go to login page to login")</script>';}
else {
echo '<script type="text/javascript"> alert ("Error")' ;}
}

}
else
{
echo'<script type="text/javascript">
 alert ("Password and confirm password does not match") </script>';}

}
?>

</DIV>

</BODY>
</HTML>