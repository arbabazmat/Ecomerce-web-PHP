<?php
    session_start();
    require 'dbconflict/php.php';
    $nProdID = $_COOKIE['nCartItem'];
    $strQuery = "Select * from tblproducts where prod_ID=".$nProdID;
    $nResult = mysqli_query($con, $strQuery);
    $row = mysqli_fetch_assoc($nResult);
    
    $nOrderPrice = $row['prod_Price'];
    $nCustomerID = $_SESSION['userid'];
    
    $strQuery = "insert into tblorder (prod_ID, order_Total, order_Status, order_Date, cust_ID) values ($nProdID, $nOrderPrice, 'pending', '".date("Y-m-d H:i:s")."', $nCustomerID)";
    mysqli_query($con, $strQuery);
    setcookie("nCartItem","", time()-3600, "/");
    unset ($_COOKIE['nCartItem']);
    header("Location: thankyou.php")
?>