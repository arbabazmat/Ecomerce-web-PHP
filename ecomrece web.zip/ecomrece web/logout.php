<?php
    session_start();
    $_SESSION['bCustLogin'] = false;
    unset($_SESSION['bCustLogin']);
    unset($_SESSION['username']);
    unset($_SESSION['userid']);
    header("Location: index.php?bLogout=1");
?>