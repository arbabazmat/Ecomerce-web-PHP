<?php
    session_start();
    require_once 'check_session.php';
    require_once '../dbconflict/php.php';
    
    /*$strCustName = $_POST['strCustName'];
    $strEmail = $_POST['strEmail'];
    $strPhone = $_POST['strPhone'];
    $strAddress = $_POST['strAddress'];*/
    $strStatus = $_POST['strStatus'];
    $nID = $_POST['nID'];
    if($nID>0)
    {
        $strQuery = "update tblorder set order_Status='$strStatus' where order_ID=".$nID;
        mysqli_query($con,$strQuery);
    }
    header("Location: list_orders.php");
?>