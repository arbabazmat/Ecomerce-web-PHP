<?php
    session_start();
    $_SESSION['bLogin'] = false;
    unset($_SESSION['bLogin']);
    unset($_SESSION['User']);
    header("Location: index.php?nLogout=1");
?>