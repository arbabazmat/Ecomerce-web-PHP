<?php
    if(!isset($_SESSION['bLogin']) || (!$_SESSION['bLogin']))
    {
        header("Location: index.php?nError=3");
    }
?>