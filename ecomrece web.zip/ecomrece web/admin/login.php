<?php
    $bReqiure = false;
    if(!isset($_POST['strUserName']) || trim($_POST['strUserName'])=='')
    {
        $bReqiure = true;
    }
    if(!isset($_POST['strPassword']) || trim($_POST['strPassword'])=='')
    {
        $bReqiure = true;
    }
    if($bReqiure)
    {
        header("Location: index.php?nError=1");
    }
    require_once '../dbconflict/php.php';
    $strUserName = $_POST['strUserName'];
    $strPassword = $_POST['strPassword'];
    $strQuery = "Select count(*) as cnt from tbladminusers where adm_Username='$strUserName' and adm_Password='$strPassword'";
    $result =mysqli_query($con,$strQuery);
    $row = mysqli_fetch_assoc($result);
    
    $nCount = $row['cnt'];
    if($nCount==1)
    {
        session_start();
        $_SESSION['bLogin'] = true;
        $_SESSION['User'] = $strUserName;
        header('Location: home.php');
    }
    else
    {
        header("Location: index.php?nError=2");
    }
?>