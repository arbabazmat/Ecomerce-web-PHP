<?php
    session_start();
    require_once 'check_session.php';
    require_once '../dbconflict/php.php';
    if(isset($_GET['nID']) && $_GET['nID']>0)
    {
        $nID = $_GET['nID'];
        $strQuery = "Delete from tblcategory where cat_ID=".$nID;
        mysqli_query($con,$strQuery);
    }
    header("Location: cat_list.php");
?>