<?php
    session_start();
    require_once 'check_session.php';
    require_once '../dbconflict/php.php';
    
    $strCategory = $_POST['strCategory'];
    if(isset($_POST['nID']) && $_POST['nID']>0)
    {
        //UPdate
        $nID = $_POST['nID'];
        $strQuery = "Update tblcategory set cat_Title='$strCategory' where cat_ID=".$nID;
    }
    else
    {
        //Insert new
        $strQuery = "insert into tblcategory (cat_Title) values ('$strCategory')";
    }
    mysqli_query($con,$strQuery);
    header("Location: cat_list.php");
?>