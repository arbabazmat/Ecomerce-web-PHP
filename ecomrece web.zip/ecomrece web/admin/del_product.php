<?php
    session_start();
    require_once 'check_session.php';
    require_once '../dbconflict/php.php';
    if(isset($_GET['nID']) && $_GET['nID']>0)
    {
        $nID = $_GET['nID'];
        $strQuery = "select * from tblproducts where prod_ID=".$nID;
        $result = mysqli_query($con,$strQuery);
        if(mysqli_num_rows($result)==1)
        {
            $row = mysqli_fetch_assoc($result);
            $strImageName = $row['prod_Image'];
            $target_dir = "../prodimages/";
            @unlink($target_dir.$strImageName);
            $strQuery = "Delete from tblproducts where prod_ID=".$nID;
            mysqli_query($con,$strQuery);
        }
    }
    header("Location: prod_list.php");
?>