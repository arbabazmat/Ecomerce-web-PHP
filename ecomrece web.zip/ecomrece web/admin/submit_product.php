<?php
    session_start();
    require_once 'check_session.php';
    require_once '../dbconflict/php.php';
    
    $strProdTitle = $_POST['strProdTitle'];
    $nProdPrice = $_POST['nProdPrice'];
    $nCategory = $_POST['nCategory'];
    $strDescription = $_POST['strDescription'];
    
    $target_dir = "../prodimages/";
    $strImageName = $strProdTitle.basename($_FILES["strImage"]["name"]);
    $target_file = $target_dir . $strImageName;
    move_uploaded_file($_FILES["strImage"]["tmp_name"], $target_file);
    $strQuery = "insert into tblproducts (prod_Title, prod_Description, prod_Price, prod_Image, cat_ID) values ('$strProdTitle', '$strDescription', $nProdPrice, '$strImageName', $nCategory)";
    mysqli_query($con,$strQuery);
    header("Location: prod_list.php");
?>