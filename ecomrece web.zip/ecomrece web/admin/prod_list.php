<?php
    session_start();
    require_once 'check_session.php';
    require_once '../dbconflict/php.php';
    $strQuery = "Select tblproducts.prod_ID, tblproducts.prod_Title, tblproducts.prod_Price, tblcategory.cat_Title from tblproducts left join tblcategory on tblcategory.cat_ID=tblproducts.cat_ID order by tblproducts.prod_ID";
    $result = mysqli_query($con,$strQuery);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>Admin</title>
        <!--                       CSS                       -->
        <!-- Reset Stylesheet -->
        <link rel="stylesheet" href="resources/css/reset.css" type="text/css" media="screen" />
        <!-- Main Stylesheet -->
        <link rel="stylesheet" href="resources/css/style.css" type="text/css" media="screen" />
        <!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
        <link rel="stylesheet" href="resources/css/invalid.css" type="text/css" media="screen" />
        <!-- Colour Schemes
        Default colour scheme is green. Uncomment prefered stylesheet to use it.
        <link rel="stylesheet" href="resources/css/blue.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="resources/css/red.css" type="text/css" media="screen" />  
        -->
        <!-- Internet Explorer Fixes Stylesheet -->
        <!--[if lte IE 7]>
            <link rel="stylesheet" href="resources/css/ie.css" type="text/css" media="screen" />
        <![endif]-->
        <!--                       Javascripts                       -->
        <!-- jQuery -->
        <script type="text/javascript" src="resources/scripts/jquery-1.3.2.min.js"></script>
        <!-- jQuery Configuration -->
        <script type="text/javascript" src="resources/scripts/simpla.jquery.configuration.js"></script>
        <!-- Facebox jQuery Plugin -->
        <script type="text/javascript" src="resources/scripts/facebox.js"></script>
        <!-- jQuery WYSIWYG Plugin -->
        <script type="text/javascript" src="resources/scripts/jquery.wysiwyg.js"></script>
        <!-- Internet Explorer .png-fix -->
        <!--[if IE 6]>
            <script type="text/javascript" src="resources/scripts/DD_belatedPNG_0.0.7a.js"></script>
            <script type="text/javascript">
                DD_belatedPNG.fix('.png_bg, img, li');
            </script>
        <![endif]-->
    </head>
    <body>
        <div id="body-wrapper"> <!-- Wrapper for the radial gradient background -->
            <div id="sidebar">
                <div id="sidebar-wrapper"> <!-- Sidebar with logo and menu -->
                    <h1 id="sidebar-title"><a href="#">Admin</a></h1>
                    <!-- Logo (221px wide) -->
                    <a href="#"><img id="logo" src="resources/images/logo.png" alt="Simpla Admin logo" /></a>
                    <!-- Sidebar Profile links -->
                    <ul id="main-nav">  <!-- Accordion Menu -->
                        <li>
                            <a href="home.php" class="nav-top-item no-submenu"> <!-- Add the class "no-submenu" to menu items with no sub menu -->
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-top-item"> <!-- Add the class "current" to current menu item -->
                                Categories
                            </a>
                            <ul>
                                <li><a href="cat_list.php">List</a></li>
                                <li><a href="new_category.php">Add Category</a></li> <!-- Add class "current" to sub menu items also -->
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="nav-top-item current">
                                Products
                            </a>
                            <ul>
                                <li><a href="prod_list.php" class="current">List</a></li>
                                <li><a href="new_product.php">Add Product</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="nav-top-item">
                                Orders
                            </a>
                            <ul>
                                <li><a href="list_orders.php">List Orders</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="logout.php" class="nav-top-item no-submenu ">
                                Logout
                            </a>
                        </li>
                    </ul> <!-- End #main-nav -->
                </div>
            </div> <!-- End #sidebar -->
            <div id="main-content"> <!-- Main Content Section with everything -->
                <!-- Page Head -->
                <h2>Welcome </h2>
                <p id="page-intro">What would you like to do?</p>
                <div class="clear"></div> <!-- End .clear -->
                <div class="content-box"><!-- Start Content Box -->
                    <div class="content-box-header">
                        <h3>Products</h3>
                        <div class="clear"></div>
                    </div> <!-- End .content-box-header -->
                    <div class="content-box-content">
                        <div class="tab-content default-tab" id="tab1"> <!-- This is the target div. id must match the href of this div's tab -->
                            <?php
                                if(mysqli_num_rows($result)==0)
                                {
                                    ?>
                                    <div class="notification attention png_bg">
                                        <a href="#" class="close"><img src="resources/images/icons/cross_grey_small.png" title="Close this notification" alt="close" /></a>
                                        <div>
                                            There are no products available for now!
                                        </div>
                                    </div>
                                    <?php
                                }
                                else
                                {
                                    ?>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Price</th>
                                                <th>Category</th>
                                                <th>Options</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                while($row= mysqli_fetch_assoc($result))
                                                {
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $row['prod_ID'];?></td>
                                                        <td><?php echo $row['prod_Title'];?></td>
                                                        <td><?php echo $row['prod_Price'];?></td>
                                                        <td><?php echo $row['cat_Title'];?></td>
                                                        <td>
                                                            <!-- Icons -->
                                                            <!--<a href="new_product.php?nID=<?php echo $row['prod_ID'];?>" title="Edit"><img src="resources/images/icons/pencil.png" alt="Edit" /></a>-->
                                                            <a href="del_product.php?nID=<?php echo $row['prod_ID'];?>" title="Delete" onclick="return confirm('Are you sure to delete this category?');"><img src="resources/images/icons/cross.png" alt="Delete" /></a> 
                                                            <!--<a href="#" title="Edit Meta"><img src="resources/images/icons/hammer_screwdriver.png" alt="Edit Meta" /></a>-->
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                    <?php
                                }
                            ?>
                        </div> <!-- End #tab1 -->
                    </div> <!-- End .content-box-content -->
                </div> <!-- End .content-box -->
                <!-- End Notifications -->
            </div> <!-- End #main-content -->
        </div>
    </body>
</html>